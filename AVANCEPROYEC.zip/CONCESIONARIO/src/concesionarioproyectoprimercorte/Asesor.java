
package concesionarioproyectoprimercorte;

public class Asesor extends Persona {
    
}
