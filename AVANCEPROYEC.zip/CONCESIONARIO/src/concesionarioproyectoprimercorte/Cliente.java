package concesionarioproyectoprimercorte;

import java.util.Hashtable;
import javax.swing.JOptionPane;

public class Cliente extends Persona {
private Hashtable  clientes;

private int posicion=0, Ncliente =0;

private String Tipoper;
private String idcliente;

//Constructor

    public Cliente(String Tipoper, String idcliente) {
        this.Tipoper = Tipoper;
        this.idcliente = idcliente;
    }

    public Cliente(String Tipoper, String idcliente, String NroID, String tipoID, String nombres, String apellidos, String direccion) {
        super(NroID, tipoID, nombres, apellidos, direccion);
        this.Tipoper = Tipoper;
        this.idcliente = idcliente;
    }
    
// Destructor
public Cliente (){
        this.Tipoper = "";
        this.idcliente = "";
}

    private Cliente(int posicion) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }


 // Setter & getter
    public String getTipoper() {
        return Tipoper;
    }

    public void setTipoper(String Tipoper) {
        this.Tipoper = Tipoper;
    }

    public String getIdcliente() {
        return idcliente;
    }

    public void setIdcliente(String idcliente) {
        this.idcliente = idcliente;
    }

        public Cliente(String id){
         this.setIdcliente(id);
         this.setNombres(JOptionPane.showInputDialog(null, "Digite el nombre :",
               "Digite los datos del cliente", JOptionPane.QUESTION_MESSAGE));
         
         this.setApellidos(JOptionPane.showInputDialog(null, "Digite los apellidos :",
               "Digite los datos del cliente", JOptionPane.QUESTION_MESSAGE));
         
         this.setTipoID(JOptionPane.showInputDialog(null, "Digite el tipo de identificación :",
               "Digite los datos del cliente", JOptionPane.QUESTION_MESSAGE));
           
         this.setNroID(JOptionPane.showInputDialog(null, "Digite el número de ID :",
               "Digite los datos del cliente", JOptionPane.QUESTION_MESSAGE));
             
         this.setDireccion(JOptionPane.showInputDialog(null, "Digite la direccion :",
               "Digite los datos del cliente", JOptionPane.QUESTION_MESSAGE));
                   
 }
        
        public void Clientecraer(){
        clientes = new Hashtable();
        Ncliente=3;  
        try{
           for ( posicion = 0; posicion < Ncliente; posicion++) {
              clientes.put(posicion, new Cliente(posicion));
           }
       }catch(ArrayIndexOutOfBoundsException ex){
           System.out.println("Error en la edicion del docente");
       } 
       }
        
@Override
   public void mostrardatos(){
    Cliente tempocliente;
    String Aux = " ";
        for (int CL = 0; CL < 3; CL++) {

            tempocliente = (Cliente)  clientes.get(CL);
            Aux = Aux + tempocliente.getNombres()+ tempocliente.getApellidos()+tempocliente.getTipoper()
                    +tempocliente.getTipoID()+tempocliente.getNroID()+tempocliente.getDireccion()+"\n";
        }  
         JOptionPane.showMessageDialog(null, Aux,
                "Datos del cliente", JOptionPane.INFORMATION_MESSAGE);
        }
 
   
}


