
package concesionarioproyectoprimercorte;

/**
 *
 * @author maria
 */
public class Concesionario {
    
}
