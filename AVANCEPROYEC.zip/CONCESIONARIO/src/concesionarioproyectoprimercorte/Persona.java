
package concesionarioproyectoprimercorte;

import java.util.Hashtable;
import javax.swing.JOptionPane;

public class Persona {
  
    protected String NroID;
    protected String nombres;
    protected String apellidos;
    protected String direccion;
    protected String tipoID;
    
   public Persona() {
        this.NroID = "";
        this.tipoID = "";
        this.nombres ="";
        this.apellidos = "";
        this.direccion ="";
    }
    public Persona(String NroID, String tipoID, String nombres, String apellidos, String direccion) {
        this.NroID = NroID;
        this.tipoID = tipoID;
        this.nombres = nombres;
        this.apellidos = apellidos;
        this.direccion = direccion;
    } 
    public String getNroID() {
        return NroID;
    }
    public void setNroID(String NroID) {
        this.NroID = NroID;
    }
    public String getTipoID() {
        return tipoID;
    }
    public void setTipoID(String tipoID) {
        this.tipoID = tipoID;
    }
    public String getNombres() {
        return nombres;
    }
    public void setNombres(String nombres) {
        this.nombres = nombres;
    }
    public String getApellidos() {
        return apellidos;
    }
    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }
    public String getDireccion() {
        return direccion;
    }
    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }
  public void mostrardatos(){  
      System.out.println("Mostrar datos");
  } 
}
