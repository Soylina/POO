package Presentacion;

import javax.swing.JOptionPane;

/**
 *
 * @author Practica
 */
public class Cuadrado extends Cuadrilatero {
      Punto2D vertices[];
       // constructor
   public Cuadrado (int aux,int px, int py )
   {
      super( aux,px, py );
   }
      public Cuadrado(){
        vertices = new Punto2D[4];
        for(int conta=0;conta<4;conta++){
            aux =conta+1;
            px = Integer.parseInt(JOptionPane.showInputDialog("Cuadrado - Digite coordenada X del vertice "+aux));
            py = Integer.parseInt(JOptionPane.showInputDialog("Cuadrado - Digite coordenada Y del vertice "+aux));
                   if (py < 0) {
                    py = py * -1;
                } else {
                    py = py * 1;
                }
                if (px < 0) {
                    px = py * -1;
                } else {
                    px = px * 1;
                }
            vertices[conta]= new Punto2D(px,py);
        }
    }
    @Override
    public int calcularArea() {
      // En construcción código para calcular área de cuadrilatero
       double area, H,B; 
       B=((vertices[1].getX()- vertices[0].getX()));
       H=((vertices[3].getY()- vertices[0].getY()));
       area=(B*H);
       System.out.println("Area del cuadrado ="+area);
       return (int)area;
    }
    
    @Override
    public int calcularPerimetro() {
     double peri, L1,L2; 
       L1=((vertices[1].getX()-vertices[0].getX()));
       L2=((vertices[3].getY()-vertices[0].getY()));
       peri=((L1*2)+(L2*2));
       System.out.println("perimetro del cuadrado ="+peri);
       return (int)peri;
    }
    public void setColor(int idColor){
        // implementación de mi código 
    }

    @Override
    public void reDibujar() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
