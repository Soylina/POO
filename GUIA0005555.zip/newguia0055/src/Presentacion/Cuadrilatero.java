package Presentacion;
import javax.swing.JOptionPane;
public class Cuadrilatero extends Figura{

 protected int aux,px, py;

 
    
    public Cuadrilatero(int aux, int px, int py) {
        this.aux = aux;
        this.px = px;
        this.py = py;
    }
       public int getAux() {
        return aux;
    }

    public void setAux(int aux) {
        this.aux = aux;
    }

    public int getPx() {
        return px;
    }

    public void setPx(int px) {
        this.px = px;
    }

    public int getPy() {
        return py;
    }

    public void setPy(int py) {
        this.py = py;
    }
   Punto2D vertices[];
    String titulo;
    
    public Cuadrilatero(){
        vertices = new Punto2D[4];
    }
    @Override
    public int calcularArea() {
      // En construcción código para calcular área de cuadrilatero
       double area, H,B; 
       B=((vertices[1].getX()- vertices[0].getX()));
       H=((vertices[3].getY()- vertices[0].getY()));
       area=(B*H);
       System.out.println("Area del cuadrado="+area);
       return (int)area;
    }
    
    @Override
    public int calcularPerimetro() {
     double peri, L1,L2; 
       L1=((vertices[1].getX()-vertices[0].getX()));
       L2=((vertices[3].getY()-vertices[0].getY()));
       peri=((L1*2)+(L2*2));
       System.out.println("perimetro del cuadrado ="+peri);
       return (int)peri;
    }
    public void setColor(int idColor){
        // implementación de mi código 
    }

    @Override
    public void reDibujar() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
