/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Presentacion;

import java.awt.Color;
import java.awt.Graphics;
import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 
 * @author Rennier Colmenares
 */
public class Dibujar extends JPanel {
 @Override
 public void paint(Graphics g){
     super.paint(g);
    
     //A=200,200
     //B=100,600
     //C=300,600
     
     int[] puntosx={200,100,300};
     int[] puntosy={200,600,600};   
     g.setColor(Color.red);
     g.fillPolygon(puntosx,puntosy,3);
 }
    public static void main(String[] args) {
     JFrame ventana=new JFrame("Triángulo Isósceles");
    Dibujar isosceles = new Dibujar();
    ventana.add(isosceles);
    ventana.setSize(700, 700);
    ventana.setLocationRelativeTo(null);
    ventana.setVisible(true);
    ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    
    }
    
}
