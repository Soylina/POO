package Presentacion;

import javax.swing.JOptionPane;

/**
 *
 * @author Practica
 */
public class Escaleno extends Triangulo{
    Punto2D vertices [];

public Escaleno(){
        vertices = new Punto2D[3];
        for(int conta=0;conta<3;conta++){
            aux =conta+1;
            px = Integer.parseInt(JOptionPane.showInputDialog("Triangulo escaleno - Digite coordenada X del vertice "+aux));
            py = Integer.parseInt(JOptionPane.showInputDialog("Triangulo escaleno - Digite coordenada Y del vertice "+aux));
                   if (py < 0) {
                    py = py * -1;
                } else {
                    py = py * 1;
                }
                if (px < 0) {
                    px = py * -1;
                } else {
                    px = px * 1;
                }
            vertices[conta]= new Punto2D(px,py);
        }
    } 
    @Override
    public int calcularArea() {
       double area, b,h,C,S; 
       b = ((vertices[1].getX()- vertices[0].getX()));
       h= ((vertices[1].getY()- vertices[2].getY()));
       area=(b*h)/2;
       System.out.println("Area triangulo escaleno ="+area);
       return (int)area;
    }

    @Override
    public int calcularPerimetro() {
           double area, A,B,C,S; 
       A= (float) Math.sqrt((Math.pow((vertices[1].getX()-vertices[0].getX()),2))+(Math.pow((vertices[1].getY()-vertices[0].getY()),2)));
       B= (float) Math.sqrt((Math.pow((vertices[2].getX()-vertices[1].getX()),2))+(Math.pow((vertices[2].getY()-vertices[1].getY()),2)));
       C= (float) Math.sqrt((Math.pow((vertices[0].getX()-vertices[2].getX()),2))+(Math.pow((vertices[0].getY()-vertices[2].getY()),2)));
       S=(A+B+C);
       System.out.println("Perimetro triangulo escaleno="+S);
       return (int)S;
    }

    @Override
    public void reDibujar() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
