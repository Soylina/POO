package Presentacion;
public class Principal {
   
    
    Figura listado[];
  
    public Principal() {
        listado[0]= new Rectangulo();
        listado[1]= new Cuadrado();
        listado[2]= new Isosceles();
        listado[3]= new Trapecio();
        listado[4]= new Escaleno();

        for(int pos=0;pos<listado.length;pos++){
            listado[pos].calcularArea();
            listado[pos].calcularPerimetro();
      
        }
    }
    public static void main(String args[]){
        ///Principal solucion= new Principal();
         Rectangulo  Rec = new Rectangulo ();
         Isosceles isos = new Isosceles ();
         Escaleno esca= new Escaleno();
         Cuadrado zxc = new Cuadrado ();
         Trapecio trap= new Trapecio ();
        
        /// Figura zzz = new Triangulo ();
          Rec.calcularArea();
         Rec.calcularPerimetro();
         
          isos.calcularArea();
         isos.calcularPerimetro();
         
          esca.calcularArea();
         esca.calcularPerimetro();
         
         zxc.calcularArea();
         zxc.calcularPerimetro();
        
         trap.calcularArea();
         trap.calcularPerimetro();
       
        
         
    }
}
      //listado[pos].calcularArea();
      ///      listado[pos].calcularPerimetro();