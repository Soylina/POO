package Presentacion;
public class Punto2D {
    int X, Y;
    public Punto2D(int xp, int yp) {
        this.X=xp;
        this.Y=yp;  
    }
    public int getX() {
        return X;
    }

    public void setX(int X) {
        this.X = X;
    }

    public int getY() {
        return Y;
    }
    public void setY(int Y) {
        this.Y = Y;
    }
    
}
