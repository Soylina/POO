package Presentacion;

import javax.swing.JOptionPane;

/**
 *
 * @author Practica
 */
public class Rectangulo extends Triangulo{
       Punto2D vertices[];
       // constructor
   public Rectangulo(int aux,int px, int py )
   {
      super( aux,px, py );
   }
    public Rectangulo(){
        vertices = new Punto2D[3];
        for(int conta=0;conta<3;conta++){
            aux =conta+1;
            px = Integer.parseInt(JOptionPane.showInputDialog("Triangulo Rectangulo - Digite coordenada X del vertice "+aux));
            py = Integer.parseInt(JOptionPane.showInputDialog("Triangulo Rectangulo - Digite coordenada Y del vertice "+aux));
            vertices[conta]= new Punto2D(px,py);
        }
    } 
    @Override
    public int calcularArea() {
       double area, A,B,C,S; 
       A= (float) Math.sqrt((Math.pow((vertices[1].getX()-vertices[0].getX()),2))+(Math.pow((vertices[1].getY()-vertices[0].getY()),2)));
       B= (float) Math.sqrt((Math.pow((vertices[2].getX()-vertices[1].getX()),2))+(Math.pow((vertices[2].getY()-vertices[1].getY()),2)));
       C= (float) Math.sqrt((Math.pow((vertices[0].getX()-vertices[2].getX()),2))+(Math.pow((vertices[0].getY()-vertices[2].getY()),2)));
       S=(A+B+C)/2;
       area=Math.sqrt(S*(S-A)*(S-B)*(S-C));
       System.out.println("Area del triangulo Rectangulo ="+area);
       return (int)area;
    }

    @Override
    public int calcularPerimetro() {
       double area, A,B,C,S; 
       A= (float) Math.sqrt((Math.pow((vertices[1].getX()-vertices[0].getX()),2))+(Math.pow((vertices[1].getY()-vertices[0].getY()),2)));
       B= (float) Math.sqrt((Math.pow((vertices[2].getX()-vertices[1].getX()),2))+(Math.pow((vertices[2].getY()-vertices[1].getY()),2)));
       C= (float) Math.sqrt((Math.pow((vertices[0].getX()-vertices[2].getX()),2))+(Math.pow((vertices[0].getY()-vertices[2].getY()),2)));
       S=(A+B+C);
       System.out.println("Perimetro del triangulo Rectangulo ="+S);
       return (int)S;
    }

    @Override
    public void reDibujar() {
        
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
