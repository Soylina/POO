package Presentacion;

import static Presentacion.Trapecio.vertices;
import javax.swing.JOptionPane;

/**
 *
 * @author Practica
 */
public class Trapecio extends Cuadrilatero {
    static Punto2D vertices[];

    public Punto2D[] getVertices() {
        return vertices;
    }

    public void setVertices(Punto2D[] vertices) {
        this.vertices = vertices;
    }
// constructor
   public Trapecio (int aux,int px, int py )
   {
      super( aux,px, py );
   }
       public Trapecio(){
        vertices = new Punto2D[4];
        for(int conta=0;conta<4;conta++){
            aux =conta+1;
            px = Integer.parseInt(JOptionPane.showInputDialog("Trapecio - Digite coordenada X del vertice "+aux));
            py = Integer.parseInt(JOptionPane.showInputDialog("Trapecio - Digite coordenada Y del vertice "+aux));
                if (py < 0) {
                    py = py * -1;
                } else {
                    py = py * 1;
                }
                if (px < 0) {
                    px = py * -1;
                } else {
                    px = px * 1;
                }
            vertices[conta]= new Punto2D(px,py);
        }
    }
    @Override
    public int calcularArea() {           
      // En construcción código para calcular área de cuadrilatero
       double area, b,B,S,H; 
       B=((vertices[1].getX()- vertices[0].getX()));
       b=((vertices[3].getX()- vertices[2].getX()));
       H=((vertices[2].getY()- vertices[0].getY()));
       S=(B+b)/2;
       area=(S*H);
       System.out.println("Area del Trapecio ="+area);
       return (int)area;
    }
    
    @Override
    public int calcularPerimetro() {
     double H,peri, L1,L2,L; 
        L1 =((vertices[1].getX()- vertices[0].getX()));
        L2=((vertices[3].getX()- vertices[2].getX()));
       H=((vertices[2].getY()- vertices[0].getY()));
        L= (float) Math.sqrt((Math.pow((vertices[1].getX()-vertices[0].getX()/2),2))+(Math.pow((vertices[2].getY()- vertices[0].getY()/2),2)));
        L=(L*2);
        peri= (L+L1+L2);
       System.out.println("Perimetro del Trapecio ="+peri);
       return (int)peri;
    }
   @Override
    public void setColor(int idColor){
        // implementación de mi código 
    }

    @Override
    public void reDibujar() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
