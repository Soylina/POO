package Presentacion;
import javax.swing.JOptionPane;
public class Triangulo extends Figura {
protected int aux,px, py;
   Punto2D vertices[];
    public Triangulo(int aux, int px, int py) {
        this.aux = aux;
        this.px = px;
        this.py = py;
    }

    public int getAux() {
        return aux;
    }

    public void setAux(int aux) {
        this.aux = aux;
    }

    public int getPx() {
        return px;
    }

    public void setPx(int px) {
        this.px = px;
    }

    public int getPy() {
        return py;
    }

    public void setPy(int py) {
        this.py = py;
    }
public Triangulo(){
        vertices = new Punto2D[3];
       
    } 
    @Override
    public int calcularArea() {
       double area, A,B,C,S; 
       A= (float) Math.sqrt((Math.pow((vertices[1].getX()-vertices[0].getX()),2))+(Math.pow((vertices[1].getY()-vertices[0].getY()),2)));
       B= (float) Math.sqrt((Math.pow((vertices[2].getX()-vertices[1].getX()),2))+(Math.pow((vertices[2].getY()-vertices[1].getY()),2)));
       C= (float) Math.sqrt((Math.pow((vertices[0].getX()-vertices[2].getX()),2))+(Math.pow((vertices[0].getY()-vertices[2].getY()),2)));
       S=(A+B+C)/2;
       area=Math.sqrt(S*(S-A)*(S-B)*(S-C));
       System.out.println("Area ="+area);
       return (int)area;
    }

    @Override
    public int calcularPerimetro() {
       double area, A,B,C,S; 
       A= (float) Math.sqrt((Math.pow((vertices[1].getX()-vertices[0].getX()),2))+(Math.pow((vertices[1].getY()-vertices[0].getY()),2)));
       B= (float) Math.sqrt((Math.pow((vertices[2].getX()-vertices[1].getX()),2))+(Math.pow((vertices[2].getY()-vertices[1].getY()),2)));
       C= (float) Math.sqrt((Math.pow((vertices[0].getX()-vertices[2].getX()),2))+(Math.pow((vertices[0].getY()-vertices[2].getY()),2)));
       S=(A+B+C);
       System.out.println("Perimetro ="+S);
       return (int)S;
    }

    @Override
    public void reDibujar() {
        
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
