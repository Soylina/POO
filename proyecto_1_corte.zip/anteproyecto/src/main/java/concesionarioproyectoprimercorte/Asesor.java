
package concesionarioproyectoprimercorte;

import java.util.Hashtable;
import javax.swing.JOptionPane;

public class Asesor extends Persona {
    private Hashtable  asesores;

private int posicion=0, NAsesor =0;

private String Nidasesor, area;

    public Asesor (){
        this.Nidasesor = "";
        this.area = "";
    }

    public int getNAsesor() {
        return NAsesor;
    }

    public void setNAsesor(int NAsesor) {
        this.NAsesor = NAsesor;
    }
                   

    public Asesor(String Nidasesor, String area, String NroID, String tipoID, String nombres, String apellidos, String direccion) {
        super(NroID, tipoID, nombres, apellidos, direccion);
        this.Nidasesor = Nidasesor;
         this.area = area;
       
    }

    private Asesor(int posicion) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public int getPosicion() {
        return posicion;
    }

    public void setPosicion(int posicion) {
        this.posicion = posicion;
    }

    public String getNidasesor() {
        return Nidasesor;
    }

    public void setNidasesor(String Nidasesor) {
        this.Nidasesor = Nidasesor;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }
    
     public Asesor(String id){
         this.setNidasesor(id);
         this.setNombres(JOptionPane.showInputDialog(null, "Digite el nombre :",
               "Digite los datos del Asesor", JOptionPane.QUESTION_MESSAGE));
         
         this.setApellidos(JOptionPane.showInputDialog(null, "Digite los apellidos :",
               "Digite los datos del Asesor", JOptionPane.QUESTION_MESSAGE));
         
         this.setTipoID(JOptionPane.showInputDialog(null, "Digite el tipo de identificación :",
               "Digite los datos del Asesor", JOptionPane.QUESTION_MESSAGE));
           
         this.setNroID(JOptionPane.showInputDialog(null, "Digite el número de ID :",
               "Digite los datos del Asesor", JOptionPane.QUESTION_MESSAGE));
             
         this.setDireccion(JOptionPane.showInputDialog(null, "Digite la direccion :",
               "Digite los datos del Asesor", JOptionPane.QUESTION_MESSAGE));
                   
 }
        
        public void Asesorcraer(){
        asesores = new Hashtable();
        NAsesor=3;  
        try{
           for ( posicion = 0; posicion < NAsesor; posicion++) {
              asesores.put(posicion, new Asesor(posicion));
           }
       }catch(ArrayIndexOutOfBoundsException ex){
           System.out.println("Error en la edicion del docente");
       } 
       }
        
@Override
   public void mostrardatos(){
    Asesor tempoAsesor;
    String Aux = " ";
        for (int CL = 0; CL < 3; CL++) {

            tempoAsesor = (Asesor)  asesores.get(CL);
            Aux = Aux + tempoAsesor.getNombres()+ tempoAsesor.getApellidos()+tempoAsesor.getArea()
                    +tempoAsesor.getTipoID()+tempoAsesor.getNroID()+tempoAsesor.getDireccion()+"\n";
        }  
         JOptionPane.showMessageDialog(null, Aux,
                "Datos del Asesor", JOptionPane.INFORMATION_MESSAGE);
        }


    
}
