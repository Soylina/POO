
package concesionarioproyectoprimercorte;

import javax.swing.JOptionPane;

/**
 *
 * @author maria
 */
public class Concesionario {
    static  Cliente cliente = new  Cliente ();
    public static void main(String[] args){ 
        byte op=0;
        do {
            op=Byte.parseByte(JOptionPane.showInputDialog( 
                    " CONCESIONARIO DE CARROS \n"
                    +" MENU PRINCIPAL \n"      
                    + "1) Crear vehiculo\n"
                    + "2) Crear Asesor\n"
                    + "3) Crear Cliente\n"
                    + "4) Listado de Vehiculos\n"
                    + "5) Listado de Asesores\n" 
                    + "6) Listado de Clientes\n"
                    + "7) Salir (Fin del programa)\n"
                            + "Escoja por favor la opción del 1 al 7:\n"));          
            switch (op) {
                case 1:
                 
                    break;
                case 2:
                    
                    break;
                case 3:
                
                    break;
                case 4:
                    
                    break;
                case 5:
                 
                    break;
                case 6:
                 
                    break;
                case 7:
                     JOptionPane.showInputDialog(null, "Gracias, Vuelva Pronto");
                    op=7;
                    break;
                     default:
                         JOptionPane.showInputDialog(null, "Solo números entre 1 y 3 :");
                          break;
            }
        } while (op!= 7);
        System.exit(0);
    }
}
