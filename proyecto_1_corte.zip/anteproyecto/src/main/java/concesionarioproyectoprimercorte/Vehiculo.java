package concesionarioproyectoprimercorte;

public class Vehiculo {
    //Atributos
    private String marca;
    private String modelo;
    private String color;
    private String tipo;
    private String placa;
    private String ensamblaje;
    private String precio;
  
    //Destructor
    public Vehiculo() {
        this.marca ="";
        this.modelo = "";
        this.color = "";
        this.tipo = "";
        this.placa = "";
        this.ensamblaje = "";
        this.precio = "";
}
    // constructor
    public Vehiculo(String marca, String modelo, String color, String tipo, String placa, String ensamblaje, String precio) {
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
        this.tipo = tipo;
        this.placa = placa;
        this.ensamblaje = ensamblaje;
        this.precio = precio;
    }    
 // Getter & Setter
    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getPlaca() {
        return placa;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }

    public String getEnsamblaje() {
        return ensamblaje;
    }

    public void setEnsamblaje(String ensamblaje) {
        this.ensamblaje = ensamblaje;
    }

    public String getPrecio() {
        return precio;
    }

    public void setPrecio(String precio) {
        this.precio = precio;
    }
}
