package TuNominaYa;
// La superclase abstracta Empleado.

public abstract class Empleado {
   private String primerNombre;
   private String apellidoPaterno;
   private String numeroSeguroSocial;
   private String tipo;

   // constructor
   public Empleado( String nombre, String apellido, String ssn, String tipoEmpleado )
   {
      primerNombre = nombre;
      apellidoPaterno = apellido;
      numeroSeguroSocial = ssn;
      tipo = tipoEmpleado;
   } 
   
   // establecer tipo de empleado
   public void establecerTipo( String tipoEmpleado )
   {
      tipo = tipoEmpleado;
   } 

   // devolver el primer nombre
   public String obtenerTipo()
   {
      return tipo;
   } 

   // establecer el primer nombre
   public void establecerPrimerNombre( String nombre )
   {
      primerNombre = nombre;
   } 

   // devolver el primer nombre
   public String obtenerPrimerNombre()
   {
      return primerNombre;
   } 
   

   // establecer el apellido
   public void establecerApellidoPaterno( String apellido )
   {
      apellidoPaterno = apellido;
   } 

   // devolver el apellido
   public String obtenerApellidoPaterno()
   {
      return apellidoPaterno;
   } 

   // establecer el numero de seguro social
   public void establecerNumeroSeguroSocial( String numero )
   {
      numeroSeguroSocial = numero;  // deberia validarse
   } 

   // devolver el numero de seguro social
   public String obtenerNumeroSeguroSocial()
   {
      return numeroSeguroSocial;
   } 

   // devolver representacion String del objeto Empleado
   public String toString()
   {
      return obtenerPrimerNombre() + " " + obtenerApellidoPaterno() +
         "\nnumero de seguro social: " + obtenerNumeroSeguroSocial();
   } 

   // metodo abstracto sobrescrito por las subclases
   public abstract double ingresos();
   
} // fin de la clase abstracta Empleado

