package TuNominaYa;
// La clase EmpleadoBaseMasComision que extiende a EmpleadoPorComision.

public class EmpleadoBaseMasComision extends EmpleadoPorComision {
   private double salarioBase;  // salario base por semana

   // constructor
   public EmpleadoBaseMasComision( String nombre, String apellido, 
      String numeroSeguroSocial, double cantidadVentasTotales,
      double tasa, double cantidadSalarioBase, String tipo )
   {
      super( nombre, apellido, numeroSeguroSocial, cantidadVentasTotales, tasa, tipo );
      establecerSalarioBase( cantidadSalarioBase );
   } 

   // establecer el salario base del empleado con salario base mas comision
   public void establecerSalarioBase( double salario )
   {
      salarioBase = salario < 0.0 ? 0.0 : salario;
   } 

   // devolver el salario base del empleado con salario base mas comision
   public double obtenerSalarioBase()
   {
      return salarioBase;
   } 

   // calcular los ingresos del empleado con salario base mas comision;
   // sobrescribir el metodo ingresos en EmpleadoPorComision
   public double ingresos()
   {
      return obtenerSalarioBase() + super.ingresos();
   } 

   // devolver la representacion String de EmpleadoBaseMasComision
   public String toString()
   {
      return "\nempleado con salario base mas comision: " +
         super.obtenerPrimerNombre() + " " + super.obtenerApellidoPaterno() +
         "\nnumero de seguro social: " + super.obtenerNumeroSeguroSocial();
   } 
   
} // fin de la clase EmpleadoBaseMasComision

