package TuNominaYa;
// Programa de prueba de la jerarqu�a Empleado.

import java.text.DecimalFormat;
import javax.swing.JOptionPane;

public class PruebaSistemaNomina {

    public static void main(String[] args) {
        DecimalFormat dosDigitos = new DecimalFormat("0.00");

        // crear arreglo tipo Empleado
        Empleado empleados[] = new Empleado[4];

        // inicializar arreglo con Empleados
        JOptionPane.showMessageDialog(null, "Introduzca datos de empleado asalariado");
        String tipo0 = "Empleado asalariado";
        String nombre0 = JOptionPane.showInputDialog("Introduzca el nombre:");
        String apellido0 = JOptionPane.showInputDialog("Introduzca el apellido:");
        String númeroSeguridadSocial0 = JOptionPane.showInputDialog("Introduzca número de seguridad social:");
        String salario = JOptionPane.showInputDialog("Introduzca el salario:");
        double salario0 = Double.parseDouble(salario);
        empleados[0] = new EmpleadoAsalariado(nombre0, apellido0, númeroSeguridadSocial0, salario0, tipo0);
        
        JOptionPane.showMessageDialog(null, "Introduzca datos de empleado por comision");
        String tipo1 = "Empleado Comision";
        String nombre1 = JOptionPane.showInputDialog("Introduzca el nombre:");
        String apellido1 = JOptionPane.showInputDialog("Introduzca el apellido:");
        String númeroSeguridadSocial1 = JOptionPane.showInputDialog("Introduzca número de seguridad social:");
        String ventas11 = JOptionPane.showInputDialog("Introduzca el numero de ventas:");
        double ventas1 = Double.parseDouble(ventas11);
        String tasa11 = JOptionPane.showInputDialog("Introduzca el porcentaje:");
        double tasa1 = Double.parseDouble(tasa11);
        empleados[1] = new EmpleadoPorComision(nombre1, apellido1, númeroSeguridadSocial1, ventas1, tasa1, tipo1);
        
        JOptionPane.showMessageDialog(null, "Introduzca datos de empleado mas su comision");
        String tipo2 = "Empleado Comision";
        String nombre2 = JOptionPane.showInputDialog("Introduzca el nombre:");
        String apellido2 = JOptionPane.showInputDialog("Introduzca el apellido:");
        String númeroSeguridadSocial2 = JOptionPane.showInputDialog("Introduzca número de seguridad social:");
        String ventas22 = JOptionPane.showInputDialog("Introduzca el numero de ventas totales:");
        double ventas2 = Double.parseDouble(ventas22);
        String tasa22 = JOptionPane.showInputDialog("Introduzca la tasa:");
        double tasa2 = Double.parseDouble(tasa11);
        String salariobase22 = JOptionPane.showInputDialog("Introduzca el salario base:");
        double salariobase2 = Double.parseDouble(salariobase22);
        empleados[2] = new EmpleadoBaseMasComision(nombre2, apellido2,
                númeroSeguridadSocial2, ventas2, tasa2, salariobase2, tipo2);

        JOptionPane.showMessageDialog(null, "Introduzca datos de empleado por horas");
        String tipo3 = "Empleado por horas";
        String nombre3 = JOptionPane.showInputDialog("Introduzca el nombre:");
        String apellido3 = JOptionPane.showInputDialog("Introduzca el apellido:");
        String númeroSeguridadSocial3 = JOptionPane.showInputDialog("Introduzca número de seguridad social:");
        String sueldoHora = JOptionPane.showInputDialog("Introduzca sueldo por hora:");
        double sueldoHora4 = Double.parseDouble(sueldoHora);
        String horasTrabajadas = JOptionPane.showInputDialog("Introduzca las horas trabajadas:");
        double horasTrabajadas4 = Double.parseDouble(horasTrabajadas);
        empleados[3] = new EmpleadoPorHoras(nombre3, apellido3,
                númeroSeguridadSocial3, sueldoHora4, horasTrabajadas4, tipo3);
        
        

        String salida = "";

        // procesar genericamente cada elemento en el arreglo empleados
        for (int i = 0; i < empleados.length; i++) {

            salida += empleados[i].toString();

            // determinar si el elemento es un EmpleadoBaseMasComision
            if (empleados[i] instanceof EmpleadoBaseMasComision) {

                // conversion descendente de referencia a Empleado a 
                // referencia a EmpleadoBaseMasComision
                EmpleadoBaseMasComision empleadoActual
                        = (EmpleadoBaseMasComision) empleados[i];

                double salarioBaseAnterior = empleadoActual.obtenerSalarioBase();
                salida += "\nsalario base anterior: $" + salarioBaseAnterior;

                empleadoActual.establecerSalarioBase(1.10 * salarioBaseAnterior);
                salida += "\nel nuevo salario base con aumento del 10% es: $"
                        + empleadoActual.obtenerSalarioBase();

            } // fin de instruccion if

            salida += "\ngana $" + empleados[i].ingresos() + "\n";

        } // fin de instruccion for

        // obtener nombre del tipo de cada objeto en el arreglo empleados
//        for (int j = 0; j < empleados.length; j++) {
//            salida += "\nEl empleado " + (j+1) + " es un "
//                    + empleados[j] ;
//        }
        JOptionPane.showMessageDialog(null, salida);  // mostrar resultados
        System.exit(0);

    } // fin de main

} // fin de la clase PruebaSistemaNomina
