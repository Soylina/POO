package TuNominaYa;
// La superclase abstracta Empleado.

public abstract class Empleado {
   private String primerNombre;
   private String apellidoPaterno;
   private String numeroSeguroSocial;
   private String tipotrabajador;

   // constructor
   public Empleado( String nombre, String apellido, String ssn, String tipo )
   {
      primerNombre = nombre;
      apellidoPaterno = apellido;
      numeroSeguroSocial = ssn;
      tipotrabajador = tipo;
   } 

   // establecer el primer nombre
   public void establecerPrimerNombre( String nombre )
   {
      primerNombre = nombre;
   } 

   // devolver el primer nombre
   public String obtenerPrimerNombre()
   {
      return primerNombre;
   } 

   // establecer el apellido
   public void establecerApellidoPaterno( String apellido )
   {
      apellidoPaterno = apellido;
   } 

   // devolver el apellido
   public String obtenerApellidoPaterno()
   {
      return apellidoPaterno;
   } 

   // establecer el n�mero de seguro social
   public void establecerNumeroSeguroSocial( String numero )
   {
      numeroSeguroSocial = numero;  // deber�a validarse
   } 

   // devolver el n�mero de seguro social
   public String obtenerNumeroSeguroSocial()
   {
      return numeroSeguroSocial;
   } 
      public void tipotrabajaro( String tipo )
   {
      tipotrabajador = tipo;  // deber�a validarse
   } 

   // devolver el n�mero de seguro social
   public String tipotrabajador()
   {
      return tipotrabajador;
   } 

   // devolver representaci�n String del objeto Empleado
   
   
   public String toString()
   {
      return obtenerPrimerNombre() + " " + obtenerApellidoPaterno() +
         "\nnumero de seguro social: " + obtenerNumeroSeguroSocial();
   } 

   // m�todo abstracto sobrescrito por las subclases
   public abstract double ingresos();
   
} // fin de la clase abstracta Empleado

