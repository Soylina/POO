package TuNominaYa;

// Programa de prueba de la jerarqu�a Empleado.
import java.text.DecimalFormat;
import javax.swing.JOptionPane;

public class PruebaSistemaNomina {

   public static void main( String[] args ) 
   {
      DecimalFormat dosDigitos = new DecimalFormat( "0.00" );

      // crear arreglo tipo Empleado
      Empleado empleados[] = new Empleado[ 4 ];

      // inicializar arreglo con Empleados
     // se piden los datos po medio de un JOptionPane y se guardan en el arreglo
      JOptionPane.showMessageDialog(null,"Ingrese los datos del empleado Asalariado: " );
      String tipo= "Empleado Asalariado";
      String nombre= JOptionPane.showInputDialog("Digite el nombre: ");
      String apellido= JOptionPane.showInputDialog("Digite el apellido: ");
      String nsegurosocial= JOptionPane.showInputDialog("Digite el numero de seguro social: ");
      String salario=  JOptionPane.showInputDialog("Digite el salario: ");
      double salari0 = Double.parseDouble(salario);
      empleados[ 0 ] = new EmpleadoAsalariado( nombre, apellido, nsegurosocial, salari0, tipo );
      
      JOptionPane.showMessageDialog(null,"Ingrese los datos del empleado por Comision: " );
      String tipo3= "Empleado por Comision";
      String nombre3= JOptionPane.showInputDialog("Digite el nombre: ");
      String apellido3= JOptionPane.showInputDialog("Digite el apellido: ");
      String nsegurosocial3= JOptionPane.showInputDialog("Digite el numero de seguro social: ");
      String nventas=  JOptionPane.showInputDialog("Digite el numero de ventas totales semanales : ");
      double nvent4as = Double.parseDouble(nventas);
      String por= JOptionPane.showInputDialog("Digite el porcentaje: ");
      double p0r = Double.parseDouble(por);
      empleados[ 1 ] = new EmpleadoPorComision( nombre3, apellido3, 
      nsegurosocial3, nvent4as, p0r, tipo3 );
      
       JOptionPane.showMessageDialog(null,"Ingrese los datos del empleado base mas Comision: " );
      String tipo2= "Empleado base mas Comision";
      String nombre2= JOptionPane.showInputDialog("Digite el nombre: ");
      String apellido2= JOptionPane.showInputDialog("Digite el apellido: ");
      String nsegurosocial2= JOptionPane.showInputDialog("Digite el numero de seguro social: ");
      String ventast2=  JOptionPane.showInputDialog("Digite el numero de ventas totales : ");
      double vt = Double.parseDouble(ventast2);
      String tasa= JOptionPane.showInputDialog("Digite la tasa: ");
      double t = Double.parseDouble(tasa);
      String salb= JOptionPane.showInputDialog("Digite el salario Base: ");
      double salariobase = Double.parseDouble(salb);
      empleados[ 2 ] = new EmpleadoBaseMasComision( nombre2, apellido2, 
      nsegurosocial2, vt, t, salariobase, tipo2 );
      
      JOptionPane.showMessageDialog(null,"Ingrese los datos del empleado por Horas: " );
      String tipo1= "Empleado por Horas: ";
      String nombre1= JOptionPane.showInputDialog("Digite el nombre: ");
      String apellido1= JOptionPane.showInputDialog("Digite el apellido: ");
      String nsegurosocial1= JOptionPane.showInputDialog("Digite el numero de seguro social: ");
      String shora=  JOptionPane.showInputDialog("Digite su sueldo por Hora: ");
      double sh0ra = Double.parseDouble(shora);
      String horast= JOptionPane.showInputDialog("Digite sus horas trabajadas: ");
      double h0rast = Double.parseDouble(horast);
    
      empleados[ 3 ] = new EmpleadoPorHoras( nombre1, apellido1, 
        nsegurosocial1, sh0ra, h0rast, tipo1 );

      String salida = "";

      // procesar gen�ricamente cada elemento en el arreglo empleados
      for ( int i = 0; i < empleados.length; i++ ) {
         salida += empleados[ i ].toString();

         // determinar si el elemento es un EmpleadoBaseMasComision
         if ( empleados[ i ] instanceof EmpleadoBaseMasComision ) {

            // conversi�n descendente de referencia a Empleado a 
            // referencia a EmpleadoBaseMasComision
            EmpleadoBaseMasComision empleadoActual =(EmpleadoBaseMasComision)empleados[i];

            double salarioBaseAnterior = empleadoActual.obtenerSalarioBase();
            salida += "\nsalario base anterior: $" + salarioBaseAnterior;      
            
            empleadoActual.establecerSalarioBase( 1.10 * salarioBaseAnterior );
            salida += "\nel nuevo salario base con aumento del 10% es: $" +
               empleadoActual.obtenerSalarioBase();

         } // fin de instrucci�n if

         salida += "\ngana $" + empleados[ i ].ingresos() + "\n";

      } // fin de instrucci�n for

      // obtener nombre del tipo de cada objeto en el arreglo empleados
  //    for ( int j = 0; j < empleados.length; j++ )
  //     salida += "\nEl empleado " + (j+1) + " es un " +
   //         empleados[ j ]; 

      JOptionPane.showMessageDialog( null, salida );  // mostrar resultados
      System.exit( 0 );

   } // fin de main

} // fin de la clase PruebaSistemaNomina
